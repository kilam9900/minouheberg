module.exports = {
  name: "invite",
  code: `$title[Voici mon lien d'invitation :] $description[[M'ajouter](https://discord.com/oauth2/authorize?client_id=853290160863313950&scope=bot&permissions=8589934591)]
  `
}