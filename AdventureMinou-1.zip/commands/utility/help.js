module.exports = {
  name: "help",
  aliases: ["aide"],
  code: `$title[Voici la liste de mes commandes :] $description[(Toutes les commandes sont à utiliser avec le préfixe *ad!*)
    __Commandes utilitaires__
  \`start, help, reset\`

    __Commandes aventure__
  \`profil, inventory, hunt, sleep, exitbed, use, shop, buy, cook\`]
  `
}